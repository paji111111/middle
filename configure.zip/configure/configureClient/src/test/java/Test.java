import com.tool.configure.beans.ABean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Created by liuzhixin on 2017/4/14.
 */
public class Test {
    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("classpath*:atest.xml");
        ABean aBean = context.getBean(ABean.class);
        aBean.print();
    }
}
