package com.tool.configure.client;

import com.google.gson.Gson;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * Created by liuzhixin on 2017/4/13.
 */
public class ConfigureReader {

    private Properties properties;

    public ConfigureReader(Properties properties) {
        this.properties = properties;
    }

    public Properties getPropsFromServer(){
        Map<String , String> paramMap = new HashMap<>();
        paramMap.putAll((Map)properties);
        String url = paramMap.get("url");

        System.out.println("url:"+url);
        paramMap.remove("url");

        System.out.println("paramMap:"+paramMap);
        String jsonResult = HttpUtilsCommon.doPost(url , paramMap , "UTF-8");

        Properties retProperties = new Properties();
        if (StringUtils.isNotBlank(jsonResult)){
            Gson gson = new Gson();
            System.out.println(" ------------ "+ jsonResult );
            RetResult retResult = gson.fromJson(jsonResult , RetResult.class);
            if (retResult.getCode() == 100){
                for (Map<String,String> map : retResult.getData()){
                    // 取出对应的 key value
                    retProperties.put(map.get("keyName"),map.get("value"));
                }
            }
        }

        return retProperties;
    }


}
