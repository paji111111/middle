package com.tool.configure.client;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.net.*;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Created by liuzhixin on 2016/12/28.
 */
public class HttpUtilsCommon {

    private static Logger logger = LoggerFactory.getLogger(HttpUtilsCommon.class);

    /**
     * 链接超时
     */
    private static int connectTimeout = 15000;

    /**
     * 读取超时
     */
    private static int readTimeout = 50000;


    public static String doPost(String url, Map<String, String> parameters, String charset) {
        Map<String, String> headerParameters = new HashMap<>();
        HttpURLConnection urlConn = null;
        try {
            urlConn = sendPost(url, parameters, charset);
            if (200 == urlConn.getResponseCode()) {
                String responseContent = getContent(urlConn, charset);
                return responseContent.trim();
            } else {
                throw new RuntimeException("http responseCode is " + urlConn.getResponseCode());
            }
        } catch (Exception e) {
            if (urlConn != null) {
                urlConn.disconnect();
                urlConn = null;
            }
            logger.error("error", e);
        } finally {
            if (urlConn != null) {
                urlConn.disconnect();
            }
        }
        return null;
    }

    private static String getContent(HttpURLConnection urlConn, String charset) {
        try {
            InputStream in = urlConn.getInputStream();
            BufferedReader rd = new BufferedReader(new InputStreamReader(in, charset));
            String tempLine = rd.readLine();
            StringBuffer tempStr = new StringBuffer();
            while (tempLine != null) {
                tempStr.append(tempLine);
                tempLine = rd.readLine();
            }
            String responseContent = tempStr.toString();
            rd.close();
            in.close();
            return responseContent;
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    private static HttpURLConnection sendPost(String urlLoc, Map<String, String> parameters,String charset) {

        String params = generatorParamString(parameters, charset);
        HttpURLConnection urlConn = null;
        try {
            URL url = new URL(urlLoc);
            urlConn = (HttpURLConnection) url.openConnection();

            urlConn.setRequestMethod("POST");
            urlConn.setConnectTimeout(connectTimeout);// （单位：毫秒）jdk
            urlConn.setReadTimeout(readTimeout);// （单位：毫秒）jdk 1.5换成这个,读操作超时

            urlConn.setDoOutput(true);
            byte[] b = params.getBytes();
            urlConn.getOutputStream().write(b, 0, b.length);
            urlConn.getOutputStream().flush();
            urlConn.getOutputStream().close();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (ProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return urlConn;
    }

    private static String generatorParamString(Map<String, String> parameters, String charset) {
        StringBuffer params = new StringBuffer();
        if (parameters != null) {
            for (Iterator<String> iter = parameters.keySet().iterator(); iter.hasNext(); ) {
                String name = iter.next();
                String value = parameters.get(name);
                value = StringUtils.isBlank(value) ? "" : value;
                params.append(name + "=");
                try {
                    params.append(URLEncoder.encode(value, charset));
                } catch (UnsupportedEncodingException e) {
                    throw new RuntimeException(e.getMessage(), e);
                } catch (Exception e) {
                    String message = String.format("'%s'='%s'", name, value);
                    throw new RuntimeException(message, e);
                }

                if (iter.hasNext()) {
                    params.append("&");
                }
            }
        }
        return params.toString();
    }

}
