package com.tool.configure.beans;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Created by liuzhixin on 2017/4/14.
 */
@Component
public class ABean {
    @Value("${tt}")
    private String tt;

    @Value("${ss}")
    private String ss;

    @Value("${st}")
    private String st;


    public void print(){
        System.out.println("tt ==="+ tt);
        System.out.println("ss ==="+ ss);
        System.out.println("st ==="+ st);
    }
}
