package com.tool.configure.client;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.util.PropertyPlaceholderHelper;
import org.springframework.util.StringValueResolver;

import java.util.Properties;

/**
 * Created by liuzhixin on 2017/4/14.
 */
public class ConfigurePlaceholderConfigurerSupport extends AbstractPlaceholderConfigurerSupport {

    @Override
    protected void processProperties(ConfigurableListableBeanFactory beanFactoryToProcess, Properties props) {

        StringValueResolver valueResolver = new ConfigurePlaceholderResolvingStringValueResolver(props);
        doProcessProperties(beanFactoryToProcess, valueResolver);
    }


    private class ConfigurePlaceholderResolvingStringValueResolver implements StringValueResolver {

        private PropertyPlaceholderHelper helper;

        private PropertyPlaceholderHelper.PlaceholderResolver resolver;

        public ConfigurePlaceholderResolvingStringValueResolver(Properties props) {
            this.helper = new PropertyPlaceholderHelper(
                    placeholderPrefix, placeholderSuffix, valueSeparator, ignoreUnresolvablePlaceholders);
            this.resolver = new ConfigurePropertyPlaceholderConfigurerResolver(props);
        }

        @Override
        public String resolveStringValue(String strVal) throws BeansException {
            String value = this.helper.replacePlaceholders(strVal, this.resolver);
            return (value.equals(nullValue) ? null : value);
        }
    }

    private class ConfigurePropertyPlaceholderConfigurerResolver implements PropertyPlaceholderHelper.PlaceholderResolver {

        private Properties props;

        private ConfigurePropertyPlaceholderConfigurerResolver(Properties props) {
            this.props = props;
        }

        @Override
        public String resolvePlaceholder(String placeholderName) {
            return ConfigurePlaceholderConfigurerSupport.this.resolvePlaceholder(placeholderName, props);
        }
    }
}
