package com.tool.configure.client;

import java.util.List;
import java.util.Map;

/**
 * Created by liuzhixin on 2017/4/13.
 */
public class RetResult {
    private Integer code;
    private String message;
    private List<Map<String,String>> data;

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<Map<String, String>> getData() {
        return data;
    }

    public void setData(List<Map<String, String>> data) {
        this.data = data;
    }
}
