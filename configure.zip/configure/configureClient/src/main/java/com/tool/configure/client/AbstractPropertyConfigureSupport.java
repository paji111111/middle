package com.tool.configure.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.core.Ordered;
import org.springframework.core.PriorityOrdered;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.EncodedResource;
import org.springframework.core.io.support.PropertiesLoaderUtils;

import java.io.IOException;
import java.util.Properties;

import static org.apache.commons.collections.ExtendedProperties.convertProperties;

/**
 * Created by liuzhixin on 2017/4/13.
 */
public abstract class AbstractPropertyConfigureSupport implements BeanFactoryPostProcessor, PriorityOrdered {
    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    private Resource location;
    private int order = Ordered.LOWEST_PRECEDENCE;  // default: same as non-Ordered


    @Override
    public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {
        Properties mergedProps = getPropertiesFromServer();

        // Convert the merged properties, if necessary.
        convertProperties(mergedProps);

        // Let the subclass process the properties.
        processProperties(beanFactory, mergedProps);
    }

    private Properties getPropertiesFromServer() {
        Properties properties = new Properties();

        try {
            PropertiesLoaderUtils.fillProperties(properties, new EncodedResource(location, "UTF-8"));
        } catch (IOException e) {
            e.printStackTrace();
            this.logger.warn("Could not load properties from " + location + ": " + e.getMessage());
        }

        ConfigureReader configureReader = new ConfigureReader(properties);
        return  configureReader.getPropsFromServer();
    }

    protected abstract void processProperties(ConfigurableListableBeanFactory beanFactory, Properties mergedProps);

    //    private void processProperties(ConfigurableListableBeanFactory beanFactoryToProcess, Properties props)
//            throws BeansException {
//        StringValueResolver valueResolver = new PlaceholderResolvingStringValueResolver(props);
//        doProcessProperties(beanFactoryToProcess, valueResolver);
//    }

    public void setOrder(int order) {
        this.order = order;
    }

    @Override
    public int getOrder() {
        return this.order;
    }

    public void setLocation(Resource location) {
        this.location = location;
    }

}
