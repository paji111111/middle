package com.tool.configure.response;

import java.io.Serializable;
import java.util.List;

/**
 * Created by liuzhixin on 2017/3/31.
 */
public class DomainResponseDto implements Serializable {
    private static final long serialVersionUID = -3871332618141300961L;

    private Long id;
    private String domainName;
    private List<ProfileResponseDto> profileList;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDomainName() {
        return domainName;
    }

    public void setDomainName(String domainName) {
        this.domainName = domainName;
    }

    public List<ProfileResponseDto> getProfileList() {
        return profileList;
    }

    public void setProfileList(List<ProfileResponseDto> profileList) {
        this.profileList = profileList;
    }

    @Override
    public String toString() {
        return "DomainResponseDto{" +
                "id=" + id +
                ", domainName='" + domainName + '\'' +
                ", profileList=" + profileList +
                '}';
    }
}
