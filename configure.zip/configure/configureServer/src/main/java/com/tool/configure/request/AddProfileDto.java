package com.tool.configure.request;

import java.io.Serializable;

/**
 * Created by liuzhixin on 2017/3/30.
 */
public class AddProfileDto implements Serializable {
    private static final long serialVersionUID = -2990157759713615786L;

    private String profileName;

    public String getProfileName() {
        return profileName;
    }

    public void setProfileName(String profileName) {
        this.profileName = profileName;
    }

    @Override
    public String toString() {
        return "AddProfileDto{" +
                "profileName='" + profileName + '\'' +
                '}';
    }
}
