package com.tool.configure.service;

import com.tool.configure.dao.DomainDao;
import com.tool.configure.entity.DomainEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by liuzhixin on 2017/3/30.
 */
@Service
public class DomainService {

    @Autowired
    private DomainDao domainDao;

    @Transactional(rollbackFor = Exception.class)
    public Long addDomain(String domainName ) throws Exception {
        // 检查domain是否存在  已存在 则不再插入

        DomainEntity domainEntity = new DomainEntity();
        domainEntity.setDomainName(domainName);
        domainEntity.setDeleted(0);
        Integer count =  domainDao.listCount(domainEntity);
        if (count>0)
            throw new Exception("已存在域");

        domainEntity.setCreated(System.currentTimeMillis());
        domainEntity.setUpdated(System.currentTimeMillis());
        domainEntity.setDeleted(0);

        int effectNum = domainDao.insert(domainEntity);
        if (effectNum ==1)
            return domainEntity.getId();
        return null;
    }

    @Transactional(rollbackFor = Throwable.class)
    public int deleteDomain(Long id) {
        //  删除domain
        DomainEntity domainEntity = new DomainEntity();
        domainEntity.setDeleted(1);
        int s = domainDao.updateById(domainEntity);

        return s;
    }


    public DomainEntity detail(Long id){
        return domainDao.selectById(id);
    }

    public List<DomainEntity> list(String domainName, Integer page, Integer pageSize) {
        // 模糊查询
        DomainEntity domainEntity = new DomainEntity();
        domainEntity.setDomainName(domainName);
        Integer start = (page-1)*pageSize ;
        return domainDao.list(domainEntity ,start , pageSize );
    }

    public Integer totalCount(String domainName) {
        // 模糊查询
        DomainEntity domainEntity = new DomainEntity();
        domainEntity.setDomainName(domainName);
        return domainDao.listCount(domainEntity );
    }
}
