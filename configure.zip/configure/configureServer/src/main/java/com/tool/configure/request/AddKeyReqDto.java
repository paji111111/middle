package com.tool.configure.request;

import java.io.Serializable;

/**
 * Created by liuzhixin on 2017/3/31.
 */
public class AddKeyReqDto implements Serializable {

    private static final long serialVersionUID = 3973176573969282282L;

    private Long domainId;

    private String keyName;


    public Long getDomainId() {
        return domainId;
    }

    public void setDomainId(Long domainId) {
        this.domainId = domainId;
    }

    public String getKeyName() {
        return keyName;
    }

    public void setKeyName(String keyName) {
        this.keyName = keyName;
    }

    @Override
    public String toString() {
        return "AddKeyReqDto{" +
                "domainId=" + domainId +
                ", keyName='" + keyName + '\'' +
                '}';
    }
}
