package com.tool.configure.dao;

import com.tool.configure.entity.DomainEntity;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by liuzhixin on 2017/3/30.
 */
public interface DomainDao {
    public DomainEntity selectById(Long id);
    public int insert(DomainEntity domainEntity);
    public int updateById( DomainEntity domainEntity );
    public List<DomainEntity> list(@Param("domainEntity") DomainEntity domainEntity , @Param("start") Integer start , @Param("maxCount") Integer maxCount);
    public Integer listCount(DomainEntity domainEntity);
}
