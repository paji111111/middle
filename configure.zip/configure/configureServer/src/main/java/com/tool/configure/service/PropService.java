package com.tool.configure.service;

import com.tool.configure.dao.PropDao;
import com.tool.configure.entity.PropEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by liuzhixin on 2017/3/30.
 */
@Service
public class PropService {

    @Autowired
    private PropDao propDao;

    @Transactional(rollbackFor = Exception.class)
    public Long addProp(Long domainId, Long profileId, String keyName, String value) throws Exception {

        PropEntity propEntity = new PropEntity();
        propEntity.setDeleted(0);
        propEntity.setDomainId(domainId);
        propEntity.setProfileId(profileId);
        propEntity.setKeyName(keyName);

        int count = propDao.listCount(propEntity);
        if (count == 0) {
            propEntity.setValue(value);
            propEntity.setCreated(System.currentTimeMillis());
            propEntity.setUpdated(System.currentTimeMillis());
            propDao.insert(propEntity);
           // int i = 100/0;
            return propEntity.getId();
        } else{
            throw new Exception("已存在该属性值，请修改设置");
        }
    }

    public int edit(Long id, String value) {
        PropEntity propEntity = new PropEntity();
        propEntity.setId(id);
        propEntity.setValue(value);
        propEntity.setUpdated(System.currentTimeMillis());
        return propDao.updateById(propEntity);
    }

    public List<PropEntity> list(Long domainId , Long profileId) {
        PropEntity propEntity = new PropEntity();
        propEntity.setDomainId(domainId);
        propEntity.setProfileId(profileId);
        propEntity.setDeleted(0);
        return propDao.list(propEntity , 0 , Integer.MAX_VALUE);
    }
}
