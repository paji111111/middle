package com.tool.configure.interceptor;

import com.tool.configure.response.ResponseDto;
import com.tool.configure.util.ResponseUtil;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.LocalVariableTableParameterNameDiscoverer;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;

/**
 * Created by liuzhixin on 2017/4/8.
 */
@Component
@Aspect
public class LoggerInterceptor {
    private Logger logger = LoggerFactory.getLogger(this.getClass());


    @Pointcut(value = "execution(* com.tool.configure.controller.*Controller*.*(..))")
    public void pointcut() {
    }

    @Around(value = "pointcut()")
    public Object aroundRecordLog(ProceedingJoinPoint pjp) throws NoSuchMethodException {

        long start = System.currentTimeMillis();
        StringBuilder stringBuilder = new StringBuilder();

        Signature sig = pjp.getSignature();
        MethodSignature msig = (MethodSignature) sig;
        Object target = pjp.getTarget();
        String className = target.getClass().getName();
        Method currentMethod = target.getClass().getMethod(msig.getName(), msig.getParameterTypes());
        LocalVariableTableParameterNameDiscoverer paramNameDiscover = new LocalVariableTableParameterNameDiscoverer();
        String paramNames[] = paramNameDiscover.getParameterNames(currentMethod);

        //拼接类名
        stringBuilder.append(className).append(".");
        //拼接方法名
        stringBuilder.append(currentMethod.getName()).append(" -> ");

        Object[] values = pjp.getArgs();
        //拼接参数key=value
        stringBuilder.append("requestParams【");
        if (null != values && null != paramNames && paramNames.length == values.length) {
            StringBuilder stringBuilderTmp = new StringBuilder();
            for (int i = 0; i < values.length; i++) {
                stringBuilderTmp.append(paramNames[i]).append("=").append(values[i]).append("&");
            }
            if (stringBuilderTmp.length() > 0) {
                stringBuilder.append(stringBuilderTmp.substring(0, stringBuilderTmp.lastIndexOf("&"))).append("】");
            }
        }
        stringBuilder.append(" 】");
        try {
            Object object = pjp.proceed();
            stringBuilder.append("   response_result【").append(object).append("】");
            return object;
        } catch (Throwable throwable) {
            logger.error("", throwable);
            ResponseDto responseDto = ResponseUtil.getFailResponseDto(throwable.getMessage());
            stringBuilder.append("   response_result【").append(responseDto).append("】");
            return responseDto;
        } finally {
            long end = System.currentTimeMillis();
            stringBuilder.append("  takes times【").append(end - start).append(" ms ").append("】");
            if (!className.contains("RootController")) {
                logger.debug(stringBuilder.toString());
            }
        }
    }


}
