package com.tool.configure.response;

/**
 * Created by liuzhixin on 2017/3/30.
 */
public enum ResponseCodeEnum {
    SUCCESS(100,"成功"),
    FAIL(200,"失败"),
    ERROR(400,"系统错误"),
    ;

    private Integer code;
    private String message;

    ResponseCodeEnum(Integer code, String message) {
        this.code = code;
        this.message = message;
    }

    public Integer getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

}
