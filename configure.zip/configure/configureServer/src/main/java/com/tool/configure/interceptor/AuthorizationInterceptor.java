package com.tool.configure.interceptor;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/** 鉴别权限
 * Created by liuzhixin on 2017/3/30.
 */
public class AuthorizationInterceptor extends HandlerInterceptorAdapter {

    /**
     * 校验用户以及操作是否合法
     * @param request
     * @param response
     * @param handler
     * @return
     * @throws Exception
     */
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {



        return true;


    }
}
