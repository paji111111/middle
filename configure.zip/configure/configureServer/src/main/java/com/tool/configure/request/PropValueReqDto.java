package com.tool.configure.request;

/**
 * Created by liuzhixin on 2017/4/12.
 */
public class PropValueReqDto {
    private Long profileId;
    private String value;

    public Long getProfileId() {
        return profileId;
    }

    public void setProfileId(Long profileId) {
        this.profileId = profileId;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return "PropValueReqDto{" +
                "profileId=" + profileId +
                ", value='" + value + '\'' +
                '}';
    }
}
