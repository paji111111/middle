package com.tool.configure.controller;

import com.tool.configure.entity.DomainEntity;
import com.tool.configure.entity.DomainProfileEntity;
import com.tool.configure.entity.ProfileEntity;
import com.tool.configure.request.AddDomainProfileReqDto;
import com.tool.configure.request.AddDomainReqDto;
import com.tool.configure.response.DomainResponseDto;
import com.tool.configure.response.ProfileResponseDto;
import com.tool.configure.response.ResponseDto;
import com.tool.configure.service.DomainProfileService;
import com.tool.configure.service.DomainService;
import com.tool.configure.service.ProfileService;
import com.tool.configure.util.ResponseUtil;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 项目设置相关
 * Created by liuzhixin on 2017/3/30.
 */
@RestController
@RequestMapping("/domain")
@ResponseBody
public class DomainController {

    @Autowired
    private DomainService domainService;

    @Autowired
    private DomainProfileService domainProfileService;

    @Autowired
    private ProfileService profileService;

    @RequestMapping(value = "/add")
    public ResponseDto<Long> addDomain(AddDomainReqDto addDomainReqDto) {
        try {
            Long id = domainService.addDomain(addDomainReqDto.getDomainName());
            return ResponseUtil.getSuccessResponseDto(id);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseUtil.getFailResponseDto();
        }
    }


    @RequestMapping(value = "/addDomainProfile")
    public ResponseDto<Long> addDomainProfile(AddDomainProfileReqDto addDomainProfileReqDto) {
        try {
            Long id = domainProfileService.add(addDomainProfileReqDto.getDomainId() , addDomainProfileReqDto.getProfileId());
            return ResponseUtil.getSuccessResponseDto(id);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseUtil.getFailResponseDto();
        }
    }

    @RequestMapping(value = "/domainProfile")
    public ResponseDto<List<ProfileResponseDto>> domainProfileList(Long domainId) {
        try {
            List<ProfileResponseDto> list = queryProfileListByDomainId(domainId);
            return ResponseUtil.getSuccessResponseDto(list);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseUtil.getFailResponseDto();
        }
    }

    @RequestMapping(value = "/detail")
    public ResponseDto<DomainResponseDto> detail(Long domainId) {
        try {
            DomainEntity domainEntity = domainService.detail(domainId);
            DomainResponseDto domainResponseDto = new DomainResponseDto();
            BeanUtils.copyProperties(domainEntity,domainResponseDto);
            List<ProfileResponseDto> list = queryProfileListByDomainId(domainId);
            domainResponseDto.setProfileList(list);
            return ResponseUtil.getSuccessResponseDto(domainResponseDto);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseUtil.getFailResponseDto();
        }
    }

    @RequestMapping(value = "/list")
    public ResponseDto<List<DomainResponseDto>> list() {

        List<DomainEntity> domainEntityList = domainService.list(null, 1, 100000);
        List<DomainProfileEntity> domainProfileEntityList = domainProfileService.list(null,null);
        List<ProfileEntity> profileEntityList = profileService.list();

        Map<Long , List<ProfileResponseDto>> domainProfileMap = new HashMap<>();
        for (DomainProfileEntity domainProfileEntity : domainProfileEntityList){
            domainProfileMap.putIfAbsent(domainProfileEntity.getDomainId(), new ArrayList<>());

            for (ProfileEntity profileEntity: profileEntityList){
                if (domainProfileEntity.getProfileId().equals(profileEntity.getId())){
                    ProfileResponseDto profileResponseDto = new ProfileResponseDto();
                    BeanUtils.copyProperties(profileEntity , profileResponseDto);
                    domainProfileMap.get(domainProfileEntity.getDomainId()).add(profileResponseDto);
                }
            }
        }

        List<DomainResponseDto> list = new ArrayList<DomainResponseDto>();
        for (DomainEntity domainEntity : domainEntityList) {
            DomainResponseDto domainResponseDto = new DomainResponseDto();

            domainResponseDto.setId(domainEntity.getId());
            domainResponseDto.setDomainName(domainEntity.getDomainName());
            domainResponseDto.setProfileList(domainProfileMap.get(domainEntity.getId()));

            list.add(domainResponseDto);
        }

        return ResponseUtil.getSuccessResponseDto(list);
    }


    private List<ProfileResponseDto>  queryProfileListByDomainId(Long domainId){
        List<ProfileResponseDto> list = new ArrayList<>();
        List<DomainProfileEntity> domainProfileEntityList = domainProfileService.list(domainId , null);
        if (CollectionUtils.isNotEmpty(domainProfileEntityList)){
            for (DomainProfileEntity domainProfileEntity : domainProfileEntityList) {
                ProfileEntity profileEntity = profileService.detail(domainProfileEntity.getProfileId());
                ProfileResponseDto profileResponseDto = new ProfileResponseDto();
                BeanUtils.copyProperties(profileEntity,profileResponseDto);
                list.add(profileResponseDto);
            }
        }
        return list;
    }

    public ResponseDto<Long> deleteDomain(Long id) {
        //fixme  删除 关联的属性


        domainService.deleteDomain(id);
        return ResponseUtil.getSuccessResponseDto(id);
    }


}
