package com.tool.configure.service;

import com.tool.configure.dao.DomainProfileDao;
import com.tool.configure.entity.DomainProfileEntity;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by liuzhixin on 2017/3/31.
 */
@Service
public class DomainProfileService {

    @Autowired
    private DomainProfileDao domainProfileDao;

    @Transactional(rollbackFor = Exception.class)
    public Long add(Long domainId, Long profileId) throws Exception {

        DomainProfileEntity domainProfileEntity = new DomainProfileEntity();

        domainProfileEntity.setDomainId(domainId);
        domainProfileEntity.setProfileId(profileId);

        List<DomainProfileEntity> domainProfileEntityList = domainProfileDao.list(domainProfileEntity);
        if (CollectionUtils.isEmpty(domainProfileEntityList)) {
            domainProfileDao.insert(domainProfileEntity);
            return domainProfileEntity.getId();
        }else{
            throw new Exception("已存在");
        }
    }


    public int delete(Long id , Long domainId , Long profileId) {
        DomainProfileEntity domainProfileEntity = new DomainProfileEntity();
        domainProfileEntity.setId(id);
        domainProfileEntity.setDomainId(domainId);
        domainProfileEntity.setProfileId(profileId);

        return domainProfileDao.delete(domainProfileEntity);
    }

    public List<DomainProfileEntity> list(Long domainId, Long profileId) {
        DomainProfileEntity domainProfileEntity = new DomainProfileEntity();
        domainProfileEntity.setDomainId(domainId);
        domainProfileEntity.setProfileId(profileId);
        return domainProfileDao.list(domainProfileEntity);
    }
}
