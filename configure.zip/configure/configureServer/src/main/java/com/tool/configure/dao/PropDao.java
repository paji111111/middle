package com.tool.configure.dao;

import com.tool.configure.entity.PropEntity;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by liuzhixin on 2017/3/31.
 */
public interface PropDao {
    public PropEntity selectById(Long id);
    public int insert(PropEntity propEntity);
    public int updateById( PropEntity propEntity  );
    public List<PropEntity> list(@Param("propEntity") PropEntity propEntity , @Param("start") Integer start , @Param("maxCount") Integer maxCount);
    public Integer listCount(PropEntity propEntity);
}
