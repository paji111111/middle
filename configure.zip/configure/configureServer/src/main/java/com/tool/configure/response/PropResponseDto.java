package com.tool.configure.response;

import java.io.Serializable;

/**
 * Created by liuzhixin on 2017/4/10.
 */
public class PropResponseDto implements Serializable {
    private static final long serialVersionUID = 530406935078919355L;

    private Long id;
    private Long domainId;
    private Long profileId;
    private String keyName;
    private String value;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getDomainId() {
        return domainId;
    }

    public void setDomainId(Long domainId) {
        this.domainId = domainId;
    }

    public Long getProfileId() {
        return profileId;
    }

    public void setProfileId(Long profileId) {
        this.profileId = profileId;
    }

    public String getKeyName() {
        return keyName;
    }

    public void setKeyName(String keyName) {
        this.keyName = keyName;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return "PropResponseDto{" +
                "id=" + id +
                ", domainId=" + domainId +
                ", profileId=" + profileId +
                ", keyName='" + keyName + '\'' +
                ", value='" + value + '\'' +
                '}';
    }
}
