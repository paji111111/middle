package com.tool.configure.dao;

import com.tool.configure.entity.ProfileEntity;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by liuzhixin on 2017/3/31.
 */
public interface ProfileDao {
    public ProfileEntity selectById(Long id);
    public int insert(ProfileEntity profileEntity);
    public int updateById(@Param("profileEntity") ProfileEntity profileEntity );
    public List<ProfileEntity> list(@Param("profileEntity") ProfileEntity profileEntity , @Param("start") Integer start , @Param("maxCount") Integer maxCount);
    public Integer listCount(ProfileEntity profileEntity);
}
