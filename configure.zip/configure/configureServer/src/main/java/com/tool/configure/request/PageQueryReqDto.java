package com.tool.configure.request;

import java.io.Serializable;

/**
 * Created by liuzhixin on 2017/3/31.
 */
public class PageQueryReqDto implements Serializable{
    private static final long serialVersionUID = -4526185446310914651L;

    private Integer page;
    private Integer pageSize;

    public Integer getPage() {
        return page;
    }

    public void setPage(Integer page) {
        this.page = page;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    @Override
    public String toString() {
        return "PageQueryReqDto{" +
                "page=" + page +
                ", pageSize=" + pageSize +
                '}';
    }
}
