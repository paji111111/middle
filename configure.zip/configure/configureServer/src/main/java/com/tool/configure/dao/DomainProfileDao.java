package com.tool.configure.dao;

import com.tool.configure.entity.DomainProfileEntity;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by liuzhixin on 2017/3/31.
 */
public interface DomainProfileDao {
    public DomainProfileEntity selectById(Long id);
    public int insert(DomainProfileEntity domainProfileEntity);
    public int delete( DomainProfileEntity domainProfileEntity);
    public List<DomainProfileEntity> list(@Param("domainProfileEntity") DomainProfileEntity domainProfileEntity);
}
