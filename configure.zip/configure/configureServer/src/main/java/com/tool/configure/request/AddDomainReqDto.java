package com.tool.configure.request;

import java.io.Serializable;

/**
 * Created by liuzhixin on 2017/3/30.
 */
public class AddDomainReqDto implements Serializable {
    private static final long serialVersionUID = -9085356834661461388L;

    private String domainName;

    public String getDomainName() {
        return domainName;
    }

    public void setDomainName(String domainName) {
        this.domainName = domainName;
    }

    @Override
    public String toString() {
        return "AddDomainReqDto{" +
                "domainName='" + domainName + '\'' +
                '}';
    }
}
