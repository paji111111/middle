package com.tool.configure.controller;

import com.google.gson.Gson;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuzhixin on 2017/4/1.
 */
@RestController
public class TurnController {

    private String prefix = "/views";

    @RequestMapping("/login")
    public String login() {
        System.out.println("login");
        return "login";
    }

    @RequestMapping("/loginPass")
    public String a(String username, String password) {
        System.out.println(username);
        System.out.println(password);
        return "main";
    }

    @RequestMapping("/")
    public String index() {
        return "main.html";
    }

    @RequestMapping("/menumenu")
    @ResponseBody
    public String menu() {

        List<BigMenu> bigMenuList = new ArrayList<>();


        // 系统管理
        BigMenu firstBigMenu = new BigMenu();
        firstBigMenu.setId(1);
        MenuGroup menuGroup = new MenuGroup();
        menuGroup.setText("系统管理");
        menuGroup.setItems(new ArrayList<>());


        MenuItem item1 = new MenuItem();
        item1.setId(12);
        item1.setText("项目管理");
        item1.setHref(prefix+"/domain/list.html");
        menuGroup.getItems().add(item1);

        MenuItem item3 = new MenuItem();
        item3.setId(4);
        item3.setText("环境管理");
        item3.setHref(prefix+"/profile/list.html");
        menuGroup.getItems().add(item3);

        MenuItem item4 = new MenuItem();
        item4.setId(6);
        item4.setText("属性管理");
        item4.setHref(prefix+"/prop/list.html");
        menuGroup.getItems().add(item4);

        List<MenuGroup> menuGroupList = new ArrayList<>();
        menuGroupList.add(menuGroup);

        firstBigMenu.setMenu(menuGroupList);
        bigMenuList.add(firstBigMenu);

        // 业务管理
//        BigMenu secondBigMenu = new BigMenu();
//        secondBigMenu.setId(7);
//        secondBigMenu.setHomePage(9);
//        MenuGroup secondMenuGroup = new MenuGroup();
//        secondMenuGroup.setText("业务管理");
//        secondMenuGroup.setItems(new ArrayList<>());

//        MenuItem item5 = new MenuItem();
//        item5.setId(9);
//        item5.setText("查询业务");
//        item5.setHref("querybuss");
//        secondMenuGroup.getItems().add(item5);
//
//        List<MenuGroup> secondMenuGroupList = new ArrayList<>();
//        secondMenuGroupList.add(secondMenuGroup);
//
//        secondBigMenu.setMenu(secondMenuGroupList);
//        bigMenuList.add(secondBigMenu);

        Gson gson = new Gson();
        return  gson.toJson(bigMenuList);
    }


    class BigMenu {
        private Integer id;
        private Integer homePage; // 菜单首页默认打开页面
        private List<MenuGroup> menu;

        public Integer getId() {
            return id;
        }

        public void setId(Integer id) {
            this.id = id;
        }

        public Integer getHomePage() {
            return homePage;
        }

        public void setHomePage(Integer homePage) {
            this.homePage = homePage;
        }

        public List<MenuGroup> getMenu() {
            return menu;
        }

        public void setMenu(List<MenuGroup> menu) {
            this.menu = menu;
        }

        @Override
        public String toString() {
            return "{" +
                    "id=" + id +
                    ", homePage=" + homePage +
                    ", menu=" + menu +
                    '}';
        }
    }

    class MenuGroup {
        private String text;
        private List<MenuItem> items;

        public String getText() {
            return text;
        }

        public void setText(String text) {
            this.text = text;
        }

        public List<MenuItem> getItems() {
            return items;
        }

        public void setItems(List<MenuItem> items) {
            this.items = items;
        }
    }

    class MenuItem {
        private Integer id;
        private String text;
        private String href;

        public Integer getId() {
            return id;
        }

        public void setId(Integer id) {
            this.id = id;
        }

        public String getText() {
            return text;
        }

        public void setText(String text) {
            this.text = text;
        }

        public String getHref() {
            return href;
        }

        public void setHref(String href) {
            this.href = href;
        }
    }
}
