package com.tool.configure.service;

import com.tool.configure.dao.ProfileDao;
import com.tool.configure.entity.ProfileEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by liuzhixin on 2017/3/31.
 */
@Service
public class ProfileService {


    @Autowired
    private ProfileDao profileDao;

    @Transactional(rollbackFor = Exception.class)
    public Long addProfile(String profileName) throws Exception {

        ProfileEntity profileEntity = new ProfileEntity();
        profileEntity.setProfileName(profileName);

        int count = profileDao.listCount(profileEntity);
        if (count == 0) {
            profileEntity.setCreated(System.currentTimeMillis());
            profileEntity.setUpdated(System.currentTimeMillis());
            profileEntity.setDeleted(1);

            profileDao.insert(profileEntity);
            return profileEntity.getId();
        }else{
            throw new Exception("已存在"+profileName+"环境");
        }
    }


    public int delete(Long id) {
        ProfileEntity profileEntity = new ProfileEntity();
        profileEntity.setDeleted(1);
        profileEntity.setId(id);
        profileEntity.setUpdated(System.currentTimeMillis());

        return profileDao.updateById(profileEntity);
    }

    public List<ProfileEntity> list() {
        ProfileEntity profileEntity = new ProfileEntity();
        profileEntity.setDeleted(0);
        return profileDao.list(profileEntity , 0, 100);
    }

    public ProfileEntity detail(Long id) {
        if (id == null)
            return null;
        return profileDao.selectById(id);
    }

}
