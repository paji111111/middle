package com.tool.configure.response;

import java.io.Serializable;

/**
 * Created by liuzhixin on 2017/3/30.
 */
public class ResponseDto<T> implements Serializable{

    private static final long serialVersionUID = -4464175790060900873L;
    /**
     * 返回码
     */
    private Integer code;

    /**
     * 返回说明
     */
    private String message;

    /**
     * 返回数据
     */
    private T data;

    public ResponseDto(Integer code, String message , T data) {
        this.code = code;
        this.message = message;
        this.data = data;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "ResponseDto{" +
                "code=" + code +
                ", message='" + message + '\'' +
                ", data=" + data +
                '}';
    }
}
