package com.tool.configure.response;

import java.io.Serializable;

/**
 * Created by liuzhixin on 2017/4/7.
 */
public class ProfileResponseDto implements Serializable {
    private static final long serialVersionUID = 8206856044251793080L;

    private Long id;
    private String profileName;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getProfileName() {
        return profileName;
    }

    public void setProfileName(String profileName) {
        this.profileName = profileName;
    }

    @Override
    public String toString() {
        return "ProfileResponseDto{" +
                "id=" + id +
                ", profileName='" + profileName + '\'' +
                '}';
    }
}
