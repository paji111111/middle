package com.tool.configure.request;

import java.io.Serializable;
import java.util.List;

/**
 * Created by liuzhixin on 2017/3/31.
 */
public class AddPropReqDto implements Serializable {
    private static final long serialVersionUID = -1056449491601682207L;

    private Long domainId;
    private String keyName;

    private List<PropValueReqDto> propvalues;


    public Long getDomainId() {
        return domainId;
    }

    public void setDomainId(Long domainId) {
        this.domainId = domainId;
    }

    public String getKeyName() {
        return keyName;
    }

    public void setKeyName(String keyName) {
        this.keyName = keyName;
    }

    public List<PropValueReqDto> getPropvalues() {
        return propvalues;
    }

    public void setPropvalues(List<PropValueReqDto> propvalues) {
        this.propvalues = propvalues;
    }

    @Override
    public String toString() {
        return "AddPropReqDto{" +
                "domainId=" + domainId +
                ", keyName='" + keyName + '\'' +
                ", propvalues=" + propvalues +
                '}';
    }
}
