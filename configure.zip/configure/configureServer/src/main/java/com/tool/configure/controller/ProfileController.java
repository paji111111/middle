package com.tool.configure.controller;

import com.tool.configure.entity.ProfileEntity;
import com.tool.configure.request.AddProfileDto;
import com.tool.configure.response.ProfileResponseDto;
import com.tool.configure.response.ResponseDto;
import com.tool.configure.service.ProfileService;
import com.tool.configure.util.ResponseUtil;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.List;

/**
 * 环境设置
 * Created by liuzhixin on 2017/3/30.
 */
@Controller
@RequestMapping("/profile")
@ResponseBody
public class ProfileController {

    @Autowired
    private ProfileService profileService;


    @RequestMapping(value = "/add")
    public ResponseDto<Long> add(AddProfileDto addProfileDto) throws Exception {
        Long id = profileService.addProfile( addProfileDto.getProfileName());
        return ResponseUtil.getSuccessResponseDto(id);
    }

    @RequestMapping(value = "/list")
    public ResponseDto<List<ProfileResponseDto>> list() {
        List<ProfileEntity> profileEntityList = profileService.list();
        List<ProfileResponseDto> profileResponseDtoList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(profileEntityList)) {
            for (ProfileEntity profileEntity : profileEntityList) {
                ProfileResponseDto profileResponseDto = new ProfileResponseDto();
                BeanUtils.copyProperties(profileEntity, profileResponseDto);
                profileResponseDtoList.add(profileResponseDto);
            }
        }
        return ResponseUtil.getSuccessResponseDto(profileResponseDtoList);
    }

}
