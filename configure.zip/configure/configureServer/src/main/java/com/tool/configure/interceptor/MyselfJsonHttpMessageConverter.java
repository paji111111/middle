package com.tool.configure.interceptor;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.support.spring.FastJsonHttpMessageConverter;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.converter.HttpMessageNotReadableException;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * Created by liuzhixin on 2017/4/12.
 */
public class MyselfJsonHttpMessageConverter extends FastJsonHttpMessageConverter {

    public MyselfJsonHttpMessageConverter() {
        super();
    }

    @Override
    protected Object readInternal(Class<? extends Object> clazz, HttpInputMessage inputMessage) throws IOException,
            HttpMessageNotReadableException {

        ByteArrayOutputStream baos = new ByteArrayOutputStream();

        InputStream in = inputMessage.getBody();

        byte[] buf = new byte[1024];
        for (;;) {
            int len = in.read(buf);
            if (len == -1) {
                break;
            }

            if (len > 0) {
                baos.write(buf, 0, len);
            }
        }

        byte[] bytes = baos.toByteArray();

        System.out.println(new String(bytes , "utf-8"));

        return JSON.parseObject(bytes, 0, bytes.length, super.getCharset().newDecoder(), clazz);
    }

}
