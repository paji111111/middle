package com.tool.configure.request;

import java.io.Serializable;

/**
 * Created by liuzhixin on 2017/4/10.
 */
public class AddDomainProfileReqDto implements Serializable {
    private static final long serialVersionUID = -3958990748064117483L;

    private Long domainId;
    private Long profileId;

    public Long getDomainId() {
        return domainId;
    }

    public void setDomainId(Long domainId) {
        this.domainId = domainId;
    }

    public Long getProfileId() {
        return profileId;
    }

    public void setProfileId(Long profileId) {
        this.profileId = profileId;
    }

    @Override
    public String toString() {
        return "AddDomainProfileReqDto{" +
                "domainId=" + domainId +
                ", profileId=" + profileId +
                '}';
    }
}
