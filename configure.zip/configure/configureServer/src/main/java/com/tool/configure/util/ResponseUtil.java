package com.tool.configure.util;

import com.tool.configure.response.ResponseCodeEnum;
import com.tool.configure.response.ResponseDto;

/**
 * Created by liuzhixin on 2017/3/30.
 */
public class ResponseUtil {

    public static <T> ResponseDto<T> getSuccessResponseDto(T data){
        return new ResponseDto<T>(ResponseCodeEnum.SUCCESS.getCode(), ResponseCodeEnum.SUCCESS.getMessage(),data);
    }


    public static <T> ResponseDto<T> getFailResponseDto() {
        return new ResponseDto<T>(ResponseCodeEnum.FAIL.getCode(), ResponseCodeEnum.FAIL.getMessage(), null);
    }

    public static <T> ResponseDto<T> getFailResponseDto(String message) {
        return new ResponseDto<T>(ResponseCodeEnum.FAIL.getCode(), message, null);
    }
}
