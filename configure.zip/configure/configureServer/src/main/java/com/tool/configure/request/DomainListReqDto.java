package com.tool.configure.request;

import java.io.Serializable;

/**
 * Created by liuzhixin on 2017/3/31.
 */
public class DomainListReqDto extends PageQueryReqDto implements Serializable {
    private static final long serialVersionUID = 4021706113530385575L;

    private String domainName;

    public String getDomainName() {
        return domainName;
    }

    public void setDomainName(String domainName) {
        this.domainName = domainName;
    }

    @Override
    public String toString() {
        return "DomainListReqDto{" +
                "domainName='" + domainName + '\'' +
                "} " + super.toString();
    }
}
