package com.tool.configure.controller;

import com.tool.configure.entity.DomainEntity;
import com.tool.configure.entity.DomainProfileEntity;
import com.tool.configure.entity.ProfileEntity;
import com.tool.configure.entity.PropEntity;
import com.tool.configure.response.PropResponseDto;
import com.tool.configure.response.ResponseDto;
import com.tool.configure.service.DomainProfileService;
import com.tool.configure.service.DomainService;
import com.tool.configure.service.ProfileService;
import com.tool.configure.service.PropService;
import com.tool.configure.util.ResponseUtil;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuzhixin on 2017/4/13.
 */
@Controller
@RequestMapping(value = "/app")
@ResponseBody
public class AppController {

    @Autowired
    private DomainService domainService;

    @Autowired
    private ProfileService profileService;

    @Autowired
    private DomainProfileService domainProfileService;

    @Autowired
    private PropService propService;


    @RequestMapping(value = "/query")
    public ResponseDto<List<PropResponseDto>> queryAppProp(Long domainId , String profileName) throws Exception {

        // 检查domainId是否存在
        DomainEntity domainEntity = domainService.detail(domainId);
        if (domainEntity==null || domainEntity.getId()==null){
            throw new Exception("不存在的项目");
        }

        profileName = StringUtils.trim(profileName);
        // 查询profileName 是否存在
        ProfileEntity profileEntity = null;
        List<ProfileEntity> profileEntityList = profileService.list();
        for (ProfileEntity profileEntityTmp : profileEntityList ){
            if (profileEntityTmp.getProfileName().equals(profileName)){
                profileEntity = profileEntityTmp;
            }
        }

        if (profileEntity == null ){
            throw new Exception("非法的配置");
        }

        // 比对 domain 和已存在的profile 是否符合
        List<DomainProfileEntity> domainProfileEntityList = domainProfileService.list(domainId ,profileEntity.getId() );
        if (CollectionUtils.isEmpty(domainProfileEntityList) || domainProfileEntityList.size()!=1)
            throw new Exception("配置错误");

        // 根据domainid profileid 获取配置列表
        List<PropResponseDto> list = new ArrayList<>();
        List<PropEntity> propEntityList = propService.list(domainId , profileEntity.getId());
        if (CollectionUtils.isNotEmpty(propEntityList)){
            for (PropEntity propEntity:propEntityList) {
                PropResponseDto propResponseDto = new PropResponseDto();
                BeanUtils.copyProperties(propEntity , propResponseDto);
                list.add(propResponseDto);
            }
        }

        // 返回
        return ResponseUtil.getSuccessResponseDto(list);
    }

}
