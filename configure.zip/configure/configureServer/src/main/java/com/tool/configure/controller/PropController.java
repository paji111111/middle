package com.tool.configure.controller;

import com.tool.configure.entity.PropEntity;
import com.tool.configure.request.AddPropReqDto;
import com.tool.configure.request.PropValueReqDto;
import com.tool.configure.response.PropResponseDto;
import com.tool.configure.response.ResponseDto;
import com.tool.configure.service.DomainProfileService;
import com.tool.configure.service.PropService;
import com.tool.configure.util.ResponseUtil;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.List;

/** 属性设置相关
 * Created by liuzhixin on 2017/3/30.
 */
@Controller
@RequestMapping("/prop")
@ResponseBody
public class PropController {

    @Autowired
    private PropService propService;

    @Autowired
    private DomainProfileService domainProfileService;

    @RequestMapping(value = "/add")
    public ResponseDto<Long> addProp(@RequestBody AddPropReqDto addPropReqDto) throws Exception {

        System.out.println(" ==================================== ");
        System.out.println(addPropReqDto);
        if (CollectionUtils.isNotEmpty(addPropReqDto.getPropvalues())){
            for (PropValueReqDto propValueReqDto : addPropReqDto.getPropvalues()){
                propService.addProp(addPropReqDto.getDomainId() , propValueReqDto.getProfileId(), addPropReqDto.getKeyName(),propValueReqDto.getValue());
            }
        }

        return ResponseUtil.getSuccessResponseDto(0L);
    }

    /**
     * 查看某个项目下的所有的配置信息
     */
    @RequestMapping(value = "/list")
    public ResponseDto<List<PropResponseDto>> list(Long domainId){
        List<PropResponseDto> list = new ArrayList<>();
        List<PropEntity> propEntityList = propService.list(domainId , null );
        if (CollectionUtils.isNotEmpty(propEntityList)){
            for (PropEntity propEntity:propEntityList) {
                PropResponseDto propResponseDto = new PropResponseDto();
                BeanUtils.copyProperties(propEntity , propResponseDto);
                list.add(propResponseDto);
            }
        }

        return ResponseUtil.getSuccessResponseDto(list);
    }


    @RequestMapping(value = "/edit")
    public ResponseDto<Long> edit(Long id , String value){
        propService.edit(id , value);
        return ResponseUtil.getSuccessResponseDto(id);
    }



}
