package com.alibaba.otter.canal.deployer.monitor;

import com.alibaba.otter.canal.common.AbstractCanalLifeCycle;
import com.alibaba.otter.canal.common.CanalLifeCycle;

/**
 * @author jianghang 2013-2-18 下午03:19:06
 * @version 1.0.1
 */
public class ManagerInstanceConfigMonitor extends AbstractCanalLifeCycle implements InstanceConfigMonitor, CanalLifeCycle {

    public void register(String destination, InstanceAction action) {

    }

    public void unregister(String destination) {

    }

}
