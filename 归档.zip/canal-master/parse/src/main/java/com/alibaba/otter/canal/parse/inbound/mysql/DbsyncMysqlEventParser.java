package com.alibaba.otter.canal.parse.inbound.mysql;

public class DbsyncMysqlEventParser {

}
