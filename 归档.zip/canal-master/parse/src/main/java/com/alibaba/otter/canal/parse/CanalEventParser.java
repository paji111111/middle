package com.alibaba.otter.canal.parse;

import com.alibaba.otter.canal.common.CanalLifeCycle;

/**
 * 数据复制控制器
 * 
 * @author jianghang 2012-6-21 下午04:03:25
 * @version 1.0.0
 */
public interface CanalEventParser<EVENT> extends CanalLifeCycle {

}
